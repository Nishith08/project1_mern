const express = require('express')
const bodyParser = require('body-parser')
const ejs = require('ejs');
const mongoose = require('mongoose');
const cors =require("cors");
const dotenv = require('dotenv');
dotenv.config();

const userRoutes = require('./src/routes/users.js')
const adminRoutes = require('./src/routes/admin.js')
const gameRoutes = require('./src/routes/gameclubs.js')
const gamevaluesRoutes = require('./src/routes/gamevalues.js')
const appgameRoutes = require('./src/routes/app/appgames.js')
const myBidRoutes = require('./src/routes/app/mybid.js')
const gameTransactionRoutes = require('./src/routes/app/gametransaction.js')
const walleteRoutes = require('./src/routes/app/wallete.js')
const rateRoutes = require('./src/routes/app/gamerates.js')


const app = express()

app.use(cors());
app.use(bodyParser.json());

app.use(userRoutes)
app.use(adminRoutes)
app.use(gameRoutes)
app.use(gamevaluesRoutes)
app.use(appgameRoutes)
app.use(myBidRoutes)
app.use(gameTransactionRoutes)
app.use(walleteRoutes)
app.use(rateRoutes)


app.set('view engine', 'ejs')

app.get('/', (req, res) => {
  res.send('Our first Node Express Server :)')
})

app.listen(process.env.PORT, () => {
  mongoose
    .connect(process.env.MONGODB_URL)
    .then(() => console.log(`Server with database is up :) and listening to port: ${process.env.PORT}`))
    .catch((error) => console.log(error))
})
