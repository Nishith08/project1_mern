
const Game = require('../../models/Gameclub.js')


const getMybid = async (req, res) => {
  try {
    
   
   
    
    res.json({
      success: 'true',
      data: 
      [ {
        "digit": "123",
        "formattedDate": "2024-11-01",
        "points": "50",
        "type": "1",
        "clubName": {
            "name": "Club A",
            "openBids": "10:00 AM",
            "closeBids": "5:00 PM"
        }
    },
    {
        "digit": "456",
        "formattedDate": "2024-11-01",
        "points": "75",
        "type": "2",
        "clubName": {
            "name": "Club B",
            "openBids": "11:00 AM",
            "closeBids": "6:00 PM"
        }
    },
    {
        "digit": "789",
        "formattedDate": "2024-11-01",
        "points": "100",
        "type": "1",
        "clubName": {
            "name": "Club C",
            "openBids": "12:00 PM",
            "closeBids": "7:00 PM"
        }
    },
    {
        "digit": "321",
        "formattedDate": "2024-11-01",
        "points": "60",
        "type": "2",
        "clubName": {
            "name": "Club D",
            "openBids": "1:00 PM",
            "closeBids": "8:00 PM"
        }
    },
    {
        "digit": "654",
        "formattedDate": "2024-11-01",
        "points": "80",
        "type": "1",
        "clubName": {
            "name": "Club E",
            "openBids": "2:00 PM",
            "closeBids": "9:00 PM"
        }
    },
    {
        "digit": "987",
        "formattedDate": "2024-11-01",
        "points": "90",
        "type": "2",
        "clubName": {
            "name": "Club F",
            "openBids": "3:00 PM",
            "closeBids": "10:00 PM"
        }
    },
    {
        "digit": "159",
        "formattedDate": "2024-11-01",
        "points": "40",
        "type": "1",
        "clubName": {
            "name": "Club G",
            "openBids": "4:00 PM",
            "closeBids": "11:00 PM"
        }
    },
    {
        "digit": "753",
        "formattedDate": "2024-11-01",
        "points": "30",
        "type": "2",
        "clubName": {
            "name": "Club H",
            "openBids": "5:00 PM",
            "closeBids": "12:00 AM"
        }
    },
    {
        "digit": "852",
        "formattedDate": "2024-11-01",
        "points": "20",
        "type": "1",
        "clubName": {
            "name": "Club I",
            "openBids": "6:00 PM",
            "closeBids": "1:00 AM"
        }
    },
    {
        "digit": "369",
        "formattedDate": "2024-11-01",
        "points": "110",
        "type": "2",
        "clubName": {
            "name": "Club J",
            "openBids": "7:00 PM",
            "closeBids": "2:00 AM"
        }
    },
    {
        "digit": "258",
        "formattedDate": "2024-11-01",
        "points": "85",
        "type": "1",
        "clubName": {
            "name": "Club K",
            "openBids": "8:00 PM",
            "closeBids": "3:00 AM"
        }
    },
    {
        "digit": "147",
        "formattedDate": "2024-11-01",
        "points": "95",
        "type": "2",
        "clubName": {
            "name": "Club L",
            "openBids": "9:00 PM",
            "closeBids": "4:00 AM"
        }
    },
    {
        "digit": "951",
        "formattedDate": "2024-11-01",
        "points": "70",
        "type": "1",
        "clubName": {
            "name": "Club M",
            "openBids": "10:00 PM",
            "closeBids": "5:00 AM"
        }
    },
    {
        "digit": "753",
        "formattedDate": "2024-11-01",
        "points": "55",
        "type": "2",
        "clubName": {
            "name": "Club N",
            "openBids": "11:00 PM",
            "closeBids": "6:00 AM"
        }
    },
    {
        "digit": "159",
        "formattedDate": "2024-11-01",
        "points": "45",
        "type": "1",
        "clubName": {
            "name": "Club O",
            "openBids": "12:00 AM",
            "closeBids": "7:00 AM"
        }
    },
    {
        "digit": "951",
        "formattedDate": "2024-11-01",
        "points": "30",
        "type": "2",
        "clubName": {
            "name": "Club P",
            "openBids": "1:00 AM",
            "closeBids": "8:00 AM"
        }
    },
    {
        "digit": "852",
        "formattedDate": "2024-11-01",
        "points": "90",
        "type": "1",
        "clubName": {
            "name": "Club Q",
            "openBids": "2:00 AM",
            "closeBids": "9:00 AM"
        }
    },
    {
        "digit": "258",
        "formattedDate": "2024-11-01",
        "points": "60",
        "type": "2",
        "clubName": {
            "name": "Club R",
            "openBids": "3:00 AM",
            "closeBids": "10:00 AM"
        }
    },
    {
        "digit": "369",
        "formattedDate": "2024-11-01",
        "points": "35",
        "type": "1",
        "clubName": {
            "name": "Club S",
            "openBids": "4:00 AM",
            "closeBids": "11:00 AM"
        }
    },
    {
        "digit": "147",
        "formattedDate": "2024-11-01",
        "points": "80",
        "type": "2",
        "clubName": {
            "name": "Club T",
            "openBids": "5:00 AM",
            "closeBids": "12:00 PM"
        }
      }
    ]})
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
module.exports = {
  
  
  getMybid

};
