
const Game = require('../../models/Gameclub.js')


const getWallete = async (req, res) => {
  try {
    
   
   
    
    res.json({
      success: 'true',
      data:{
      "balance": "1000.00",
        "winning": "150.00",
        "refferalWinning": "50.00"
      }
})
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
module.exports = {
  
  
  getWallete

};
