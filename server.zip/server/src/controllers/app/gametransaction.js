const mongoose = require('mongoose');
const Game = require('../../models/Gameclub.js')
const User = require('../../models/User.js')
const Transaction = require('../../models/Gametransaction.js')

const getTransaction = async (req, res) => {
  try {
    
    res.json({
      success: 'true',
      data: 
      [   {
        "amount": "100.00",
        "title": "Deposit",
        "formattedDate": "2024-11-02",
        "isCredit": true
    },
    {
        "amount": "50.00",
        "title": "Withdrawal",
        "formattedDate": "2024-11-01",
        "isCredit": false
    },
    {
        "amount": "200.00",
        "title": "Bonus",
        "formattedDate": "2024-10-30",
        "isCredit": true
    },
    {
        "amount": "75.00",
        "title": "Deposit",
        "formattedDate": "2024-10-29",
        "isCredit": true
    },
    {
        "amount": "150.00",
        "title": "Withdrawal",
        "formattedDate": "2024-10-28",
        "isCredit": false
    },
    {
        "amount": "90.00",
        "title": "Transfer",
        "formattedDate": "2024-10-27",
        "isCredit": false
    },
    {
        "amount": "300.00",
        "title": "Deposit",
        "formattedDate": "2024-10-26",
        "isCredit": true
    },
    {
        "amount": "120.00",
        "title": "Bonus",
        "formattedDate": "2024-10-25",
        "isCredit": true
    },
    {
        "amount": "60.00",
        "title": "Withdrawal",
        "formattedDate": "2024-10-24",
        "isCredit": false
    },
    {
        "amount": "80.00",
        "title": "Deposit",
        "formattedDate": "2024-10-23",
        "isCredit": true
    },
    {
        "amount": "100.00",
        "title": "Transfer",
        "formattedDate": "2024-10-22",
        "isCredit": false
    },
    {
        "amount": "200.00",
        "title": "Deposit",
        "formattedDate": "2024-10-21",
        "isCredit": true
    },
    {
        "amount": "30.00",
        "title": "Bonus",
        "formattedDate": "2024-10-20",
        "isCredit": true
    },
    {
        "amount": "250.00",
        "title": "Withdrawal",
        "formattedDate": "2024-10-19",
        "isCredit": false
    },
    {
        "amount": "15.00",
        "title": "Transfer",
        "formattedDate": "2024-10-18",
        "isCredit": false
    },
    {
        "amount": "500.00",
        "title": "Deposit",
        "formattedDate": "2024-10-17",
        "isCredit": true
    },
    {
        "amount": "400.00",
        "title": "Withdrawal",
        "formattedDate": "2024-10-16",
        "isCredit": false
    },
    {
        "amount": "45.00",
        "title": "Bonus",
        "formattedDate": "2024-10-15",
        "isCredit": true
    },
    {
        "amount": "65.00",
        "title": "Deposit",
        "formattedDate": "2024-10-14",
        "isCredit": true
    },
    {
        "amount": "20.00",
        "title": "Withdrawal",
        "formattedDate": "2024-10-13",
        "isCredit": false
    },
    {
        "amount": "90.00",
        "title": "Transfer",
        "formattedDate": "2024-10-12",
        "isCredit": false
    },
    {
        "amount": "30.00",
        "title": "Bonus",
        "formattedDate": "2024-10-11",
        "isCredit": true
    }

    ]})
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
const addTransaction = async (req, res) => {
  try {
    const { token, requestType, amount, comments, status, approvalRefNo, paymentData, message } = req.body;
   
    if(!token || !requestType || !amount ||!comments){
        return res.status(400).json({
            errorMessage: "Bad request",
        });
    }
    
        const user = await User.findOne({token});

        if (!user) {
            return res.status(404).json({
                errorMessage: "User not found",
            });
        }
    
        // Increment the balance with the given amount
        const newBalance = (user.balance || 0) + Number(amount);

const objectId = new mongoose.Types.ObjectId(user._id);
const idString = objectId.toString();
        // Update the user's balance in the database
        if(comments.startsWith("approved")){
        const re = await User.findByIdAndUpdate(idString, { balance: newBalance });
          if(!re){
            return res.status(404).json({
                errorMessage: "not updated",
            });
        }
        }
        const transactionDetails = new Transaction({
            uid : idString,
            appid,
            // from here add transaction along with user wallete details..
              });
      
          await transactionDetails.save()
          
    res.json({
        success: 'true',
    message: 'Inserted successfully'
    })
  } catch (error) {
    
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
module.exports = {
  
  
  getTransaction,
  addTransaction

};
