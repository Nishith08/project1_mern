
const Game = require('../../models/Gameclub.js')


const getRate = async (req, res) => {
  try {
    
   
   
    
    res.json({
      success: 'true',
      data:[
        {
          "gameName": "Single Digit",
          "currency": "$",
          "perRate": "10",
          "rate": "100"
      },
      {
          "gameName": "Single Panna",
          "currency": "€",
          "perRate": "20",
          "rate": "200"
      },
      {
          "gameName": "Jodi Board",
          "currency": "£",
          "perRate": "15",
          "rate": "150"
      },
      {
          "gameName": "Double Panna",
          "currency": "₹",
          "perRate": "25",
          "rate": "250"
      },
      {
          "gameName": "Odd Even",
          "currency": "$",
          "perRate": "30",
          "rate": "300"
      }
]
  })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
module.exports = {
  
  
  getRate

};
