const Gamevalue = require('../../models/Gamevalues.js')
const Game = require('../../models/Gameclub.js')


const getSpecialGame = async (req, res) => {
  try {
    
   
    const { id } = req.params
if(id === 0){
  data2 = {
    panaSchedule : [
      {
        "screenId": "KINGJACKPOT",
        "id": 1,
        "name": "King Jackpot Game",
        "active": true,
        "openBids": "100",
        "closeBids": "200",
        "lotteryNumbers": "123,456",
        "openResults": "123",
        "closeResults": "456"
    },

    ]
  };
}else{
  data2 = {
    panaSchedule : [
      {
        "screenId": "KINGSTARLINE",
        "id": 1,
        "name": "King Starline Game",
        "active": true,
        "openBids": "100",
        "closeBids": "200",
        "lotteryNumbers": "123,456",
        "openResults": "123",
        "closeResults": "456"
    },
    

    ]
  };
}
    
    res.json({
      success: 'true',
      data: data2
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
const getAppGamelist = async (req, res) => {
  try {
    
    const games = await Gamevalue.find()
    data2 = games.map(game=>({
     
       //name:games.name,
        gameName:game.gamename,
        gameId:game.gameid,
        id:game.uid
        //openActive:games.staus
      

    }));
    res.json({
      success: 'true',
      data: data2
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
const getAppGamevalueslist = async (req, res) => {
  try {
    const games2 = await Game.find();

    // Get the current time in IST
    const currentTimeUTC = new Date();
    const currentTime = new Date(currentTimeUTC.getTime() + 5.5 * 60 * 60 * 1000); // Convert to IST

    const panna = games2.map(game2 => {
      const openTime = new Date(game2.opentime); // Assumes opentime is a Date object
      const closeTime = new Date(game2.closetime); // Assumes closetime is a Date object

      // Define the 1-hour windows
      const openEndTime = new Date(openTime.getTime() + 60 * 60 * 1000); // 1 hour after openTime
      const closeEndTime = new Date(closeTime.getTime() + 60 * 60 * 1000); // 1 hour after closeTime

      // Check if current time is within either 1-hour window
      const openActive = 
        (currentTime >= openTime && currentTime < openEndTime) || 
        (currentTime >= closeTime && currentTime < closeEndTime);

      return {
        screenId: "DASHBOARD",
        name: game2.gameclubname,
        openBids: game2.opentime.toLocaleTimeString(), // Convert to HH:mm format if needed
        closeBids: game2.closetime.toLocaleTimeString(),
        lotteryNumbers: "1234",
        active: game2.status,
        id: "12",
        openActive,  // Sets based on the calculated windows
        openResults: game2.openResults,
        closeResults: game2.closeResults,
      };
    });

    res.json({
      success: 'true',
      data: {
        wallet: {
          balance: "1000",
          winning: "200",
          refferalWinning: "50"
        },
        "appInfo": {
          "contact1": "+1234567890",
      "contact2": "+0987654321",
      "appName": "Your App Name",
      "appDescription": "Your App Description",
      "appSupports": "Support Details"
        },
        "gameRates": [
          {
            "gameId": 1,
            "gameName": "Lucky Draw",
            "minBet": 10,
            "maxBet": 500,
            "rate": 1.5
          },
          {
            "gameId": 2,
            "gameName": "Spin the Wheel",
            "minBet": 5,
            "maxBet": 200,
            "rate": 2.0
          },
          {
            "gameId": 3,
            "gameName": "Card Match",
            "minBet": 20,
            "maxBet": 1000,
            "rate": 1.2
          }
        ],
        
        accountInfo: {
          upiName: "Manish Kumar",
          upiId: "ticketnew@ptybl",
          "minBids": "1",
          "maxBids":"5",      
          "minWithdraw": "100",
          "maxWithdraw":"1000",
          "minDeposit":"1",
          "maxDeposit":"1000",

        },
        "commonData": [
          {
            type: "LUCKYSPIN",
            code: "DISCOUNT",
            "desc": [
            {
            "discountAmount": "5",
            "description": "Discount on next spin"
            },
            {
            "discountAmount": "10",
            "description": "Bonus for first spin"
            },
            {
              "topText": "5% Off",
              "secondaryText": "Enjoy a small discount on your next purchase!",
              "textColor": "#FFFFFF",
              "color": "#FF5733"
          },
          {
              "topText": "Free Spin",
              "secondaryText": "Try again for more rewards!",
              "textColor": "#000000",
              "color": "#FFC300"
          },
          {
              "topText": "10% Off",
              "secondaryText": "Save on your next order!",
              "textColor": "#000000",
              "color": "#28A745"
          },
          {
              "topText": "Bonus Points",
              "secondaryText": "Earn additional reward points!",
              "textColor": "#FFFFFF",
              "color": "#007BFF"
          },
          {
              "topText": "15% Off",
              "secondaryText": "Limited time discount!",
              "textColor": "#FFFFFF",
              "color": "#6F42C1"
          },
          {
              "topText": "Cashback Offer",
              "secondaryText": "Get cash back on your next purchase!",
              "textColor": "#FFFFFF",
              "color": "#DC3545"
          }
  
                    ]

          },
          {
            "topText": "Spin to Win!",
            "secondaryText": "Get amazing rewards!",
            "textColor": "#FFFFFF",
            "color": "#FF5733"
        },
        {
            "topText": "Congratulations!",
            "secondaryText": "You've won a discount!",
            "textColor": "#000000",
            "color": "#FFC300"
        },
        {
            "topText": "Try Again!",
            "secondaryText": "Better luck next time!",
            "textColor": "#FFFFFF",
            "color": "#4CAF50"
        },
          {
          "type": "REFFERAL",
                "code": "SETTINGS",
                "desc": {
                    // Referral settings
                    "referralCode":"ABC123"
                }
          },
          {
            "type": "APP",
                "code": "SETTINGS",
                "desc": {
                    "HOME_BANNER": {
                        "BANNER_HEIGHT": "200"
                    },
                     "KINGSJACKPOT_LABEL": "abc_LABEL",
                    "KINGSTARLINE_LABEL": "xyz_LABEL"

            }
          },
          {
            "type": "APP_THEME",
            "code": "SETTINGS",
            "desc": [
                {
                    "key": "QRVisible",
                    "value": "Qr",
                    "desc": "QR Code is visible for deposits"
                },
                {
                    "key": "Upi",
                    "value": "upi",
                    "desc": "UPI payment option is available"
                },
                {
                    "key": "Web",
                    "value": "web",
                    "desc": "Web payment option is available"
                }
            ]
}

        ],
      
    
        panaSchedule: panna,
        
       userQueriesData: [
{
    queryId: 1,
    userId: "user_001",
    queryText: "What are the game rules?",
    status: "resolved",
    created_at: "2024-11-01T12:00:00Z",
    response: "The game rules are... (details)"
  },
  {
    queryId: 2,
    userId: "user_002",
    queryText: "How do I reset my password?",
    status: "pending",
    created_at: "2024-11-02T09:30:00Z",
    response: null
  },
  {
    queryId: 3,
    userId: "user_003",
    queryText: "Can I change my UPI ID?",
    status: "resolved",
    created_at: "2024-11-01T15:45:00Z",
    response: "Yes, you can change your UPI ID in the account settings."
  }
]

      


    }
      })
  } catch (error) {
    console.log(error)
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}


module.exports = {
  
  
  getAppGamelist,
  getAppGamevalueslist,
  getSpecialGame

};
