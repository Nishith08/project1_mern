const Gamevalue = require('../models/Gamevalues.js')

const getGames2 = async (req, res) => {
  try {
    
    const games = await Gamevalue.find()
    
    res.json({
      status: 'SUCCESS',
      data: games
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
/* const addGame2 = async (req, res) => {
      
    try {
      const gameDetails = [
                {
                    "gamename": "Single Digit",
                    "gameid": "SD",
                    "uid": 1
                },
                {
                    "gamename": "Single Digit Bulk",
                    "gameid": "SDB",
                    "uid": 2
                },
                {
                    "gamename": "Jodi Board",
                    "gameid": "JD",
                    "uid": 3
                },
                {
                    "gamename": "Single Panna",
                    "gameid": "SP",
                    "uid": 4
                },
                {
                    "gamename": "Single Digit Bulk",
                    "gameid": "SPB",
                    "uid": 5
                },
                {
                    "gamename": "Double Panna",
                    "gameid": "DP",
                    "uid": 6
                },
                {
                    "gamename": "Double Panna Bulk",
                    "gameid": "DPB",
                    "uid": 7
                },
                {
                    "gamename": "Tripple Panna",
                    "gameid": "TP",
                    "uid": 8
                },
                {
                    "gamename": "Penal Group",
                    "gameid": "PG",
                    "uid": 9
                },
                {
                    "gamename": "Red Brackets",
                    "gameid": "RB",
                    "uid": 10
                },
                {
                    "gamename": "SPDPTP",
                    "gameid": "SPDPTP",
                    "uid": 11
                },
                {
                    "gamename": "Choice SP DP TP",
                    "gameid": "CPSPDPTP",
                    "uid": 12
                },
                {
                    "gamename": "Single Motor",
                    "gameid": "SPM",
                    "uid": 13
                },
                {
                    "gamename": "DP Motor",
                    "gameid": "DPM",
                    "uid": 14
                },
                {
                    "gamename": "Group Jodi",
                    "gameid": "GJ",
                    "uid": 15
                },
                {
                    "gamename": "Digit Based Jodi",
                    "gameid": "DBJ",
                    "uid": 16
                },
                {
                    "gamename": "Odd Even",
                    "gameid": "OE",
                    "uid": 17
                },
                {
                    "gamename": "Two Digit Panel",
                    "gameid": "TDP",
                    "uid": 18
                },
                {
                    "gamename": "Half Sangam A",
                    "gameid": "HSA",
                    "uid": 19
                },
                {
                    "gamename": "Half Sangam B",
                    "gameid": "HSB",
                    "uid": 20
                },
                {
                    "gamename": "Full Sangam",
                    "gameid": "FS",
                    "uid": 21
                }
       
        
        // Add as many objects as needed
    ];

    // Insert multiple documents at once
    const result = await Gamevalue.insertMany(gameDetails);
      console.log("Document with multiple values inserted successfully:", result);
  } catch (error) {
      console.error("Error inserting document:", error);
  }
} 
*/

module.exports = {
  getGames2,
  //addGame2
}