const Game = require('../models/Gameclub.js')

const getGames = async (req, res) => {
  try {
    const games = await Game.find()
    res.json({
      status: 'SUCCESS',
      data: games
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};

function convertTimeToDate(timeString) {
  const [hours, minutes] = timeString.split(":");
  const date = new Date();
  date.setHours(hours);
  date.setMinutes(minutes);
  date.setSeconds(0);
  date.setMilliseconds(0);
  return date;
}

const addGame = async (req, res) => {
  try {
    const { gameclubname, opentime, closetime, status } = req.body;

    // Check if required fields are present
    if (!gameclubname || !opentime || !closetime || !status) {
      return res.status(400).json({
        errorMessage: "Bad request",
      });
    }

    const formattedcn = gameclubname.toLowerCase();

    // Check if gameclubname already exists
    const isExistingGame = await Game.findOne({ gameclubname: formattedcn });
    if (isExistingGame) {
      return res.status(409).json({ errorMessage: "Game club already exists" });
    }

    // Create a new game entry with converted times
    const gameDetails = new Game({
      gameclubname: formattedcn,  // Use lowercase to prevent duplicate entries
      opentime: convertTimeToDate(opentime),
      closetime: convertTimeToDate(closetime),
      status,
    });

    // Save the new game entry
    await gameDetails.save();

    res.json({
      status: 'SUCCESS',
      message: 'Created'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    });
  }
};

const editGame = async (req, res) => {
  try {
    const { id } = req.params
    const { gameclubname, opentime, closetime, status } = req.body
    await Game.findByIdAndUpdate(id, { gameclubname, opentime, closetime, status })
    res.json({
      status: 'SUCCESS',
      message: 'Game updated successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}


const deleteGame = async (req, res) => {
  try {
    const { id } = req.params
    await Game.findByIdAndDelete(id)
    res.json({
      status: 'SUCCESS',
      message: 'Game deleted successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const statusUpdate = async (req, res) => {
  try {
    const { id } = req.params
   
    const game = await Game.findById(id);
    console.log( )
    if(game.status === "false"){
      status2 = "true";
    } else {
       status2 = "false";
    }
    await Game.findByIdAndUpdate(id, { status: status2 })
    res.json({
      status: 'SUCCESS',
      message: 'Game updated successfully'
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

module.exports = {
  getGames,
  addGame,
  editGame,
  deleteGame,
  statusUpdate
}