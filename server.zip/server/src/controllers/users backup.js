const User = require('../models/User.js')
//const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken")

const loginAppUser = async (req, res, next) => {
  try {
      const { phoneNumber, fcmToken, appId, Author} = req.body;

      if (!phoneNumber || !appId) {
          return res.status(400).json({
              errorMessage: "Bad request",
          });
      }

      const userDetails = await User.findOne({phone: phoneNumber });
      let newUserId;
      if (!userDetails) {
         
    const userDetails2 = new User({
      phone:phoneNumber, 
      token:fcmToken, 
      appid:appId,
      utype:"User"
        });

        const btoken = jwt.sign(
          { userId: userDetails2._id },
          process.env.SECRET_KEY,
          { expiresIn: "60h" }
      );

    await userDetails2.save()
    newUserId = userDetails2._id;
    data2 = {
      token:btoken,
      
      user: {
        phone:phoneNumber,
        appId:appId,
      }

    }
  }else{
    const btoken = jwt.sign(
      { userId: userDetails._id },
      process.env.SECRET_KEY,
      { expiresIn: "60h" }
  );
    await User.findByIdAndUpdate(userDetails._id, { token: fcmToken})
    newUserId = userDetails._id;
    const datasnew = await User.findById(newUserId)
    data2 = {
      token:btoken,
     
      user: {
        name:datasnew.name,
        phone:datasnew.phone,
        appid:datasnew.appid,
        email:datasnew.email
      }

    }
  }

   
  

      res.json({
          success: "true",
          fcmToken: fcmToken,
          data: data2
          //name: userDetails2.name,
      });
  } catch (error) {
      next(error);
  }
};

//


const getUsers = async (req, res) => {
  try {
    const users = await User.find()
    res.json({
      status: 'SUCCESS',
      data: users
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const createUser = async (req, res) => {
  try {
    const { name, phone, appid } = req.body;

    if (!name || !phone || !appid) {
        return res.status(400).json({
            errorMessage: "Bad request",
        });
    }
  
    const isExistingUser = await User.findOne({ phone: phone });
    if (isExistingUser) {
        return res
            .status(409)
            .json({ errorMessage: "User already exists" });
    }
  
   
    const userDetails = new User({
      name,
      phone, 
      appid, 
      utype:'User'
        });

    await userDetails.save()
    res.json({
      status: 'SUCCESS',
      message: 'Created'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};


const updateUser = async (req, res) => {
  try {
    const { id } = req.params
    const { name, phone } = req.body
    await User.findByIdAndUpdate(id, { name, phone })
    res.json({
      status: 'SUCCESS',
      message: 'User updated successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const deleteUser = async (req, res) => {
  try {
    const { id } = req.params
    await User.findByIdAndDelete(id)
    res.json({
      status: 'SUCCESS',
      message: 'User deleted successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};
module.exports = {
  
  deleteUser,
  updateUser,
  createUser,
  getUsers,
  loginAppUser

};