const User = require('../models/User.js')
//const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken")

const loginAppUser = async (req, res, next) => {
  try {
      const { phoneNumber, referCode, fcmToken, appId, Author} = req.body;

      if (!phoneNumber || !appId) {
          return res.status(400).json({
              errorMessage: "Bad request",
          });
      }

      const userDetails = await User.findOne({phone: phoneNumber });
      let newUserId;
      if (!userDetails) {
         
    const userDetails2 = new User({
      phone:phoneNumber, 
      token:fcmToken, 
      appid:appId,
      utype:"User"
        });

    await userDetails2.save()
    newUserId = userDetails2._id;
     btoken = jwt.sign(
      { userId: userDetails2._id },
      process.env.SECRET_KEY,
      { expiresIn: "60h" }
  );
    data2 = {
        id:userDetails2._id,
        firstName:"",
        lastName:"",
        email:"",
        isdCode:null,
        phoneNumber:userDetails2.phone,
        isPhoneVerified:false,
        token:fcmToken,
      inActive: false
    }
  }else{
   
    await User.findByIdAndUpdate(userDetails._id, { token: fcmToken})
    newUserId = userDetails._id;
    const datasnew = await User.findById(newUserId)
     btoken = jwt.sign(
      { userId: userDetails._id },
      process.env.SECRET_KEY,
      { expiresIn: "60h" }
  );
    data2 = {
      
        id:datasnew._id,
        firstName:"",
        lastName:"",
        email:"",
        isdCode:null,
        phoneNumber:datasnew.phone,
        isPhoneVerified:false,
        token:fcmToken,
      inActive: false
      

    }
  }

   


      res.json({
          success: "true", 
          active: "true",
           Authorization:`Bearer ${btoken}`,
        "Content-Type": "application/json",
          code: 200,
          data: data2
          //name: userDetails2.name,
      });
  } catch (error) {
      next(error);
  }
};

//


const getUsers = async (req, res) => {
  try {
    const users = await User.find()
    res.json({
      status: 'SUCCESS',
      data: users
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const createUser = async (req, res) => {
  try {
    const { name, phone, appid } = req.body;

    if (!name || !phone || !appid) {
        return res.status(400).json({
            errorMessage: "Bad request",
        });
    }
  
    const isExistingUser = await User.findOne({ phone: phone });
    if (isExistingUser) {
        return res
            .status(409)
            .json({ errorMessage: "User already exists" });
    }
  
   
    const userDetails = new User({
      name,
      phone, 
      appid, 
      utype:'User'
        });

    await userDetails.save()
    res.json({
      status: 'SUCCESS',
      message: 'Created'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};


const updateUser = async (req, res) => {
  try {
    const { id } = req.params
    const { name, phone } = req.body
    await User.findByIdAndUpdate(id, { name, phone })
    res.json({
      status: 'SUCCESS',
      message: 'User updated successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const deleteUser = async (req, res) => {
  try {
    const { id } = req.params
    await User.findByIdAndDelete(id)
    res.json({
      status: 'SUCCESS',
      message: 'User deleted successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};

const userStatusUpdate = async (req, res) => {
  try {
    const { id } = req.params
   
    const user = await User.findById(id);
    console.log(user)
    if(user.status === "Active"){
      status2 = "Inactive";
    } else {
       status2 = "Active";
    }
    await User.findByIdAndUpdate(id, { status: status2 })
    res.json({
      status: 'SUCCESS',
      message: 'User updated successfully'
    })
  } catch (error) {
    console.log(error)
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}
module.exports = {
  
  deleteUser,
  updateUser,
  createUser,
  getUsers,
  loginAppUser,
  userStatusUpdate,

};
