const Admin = require('../models/admin.js')
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");


const getAdmins = async (req, res) => {
  try {
    const users = await Admin.find()
    res.json({
      status: 'SUCCESS',
      data: users
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

const createAdmin = async (req, res) => {
  try {
    const { name, email, password, appid } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({
            errorMessage: "Bad request",
        });
    }
  
    const isExistingUser = await Admin.findOne({ email: email });
    if (isExistingUser) {
        return res
            .status(409)
            .json({ errorMessage: "Admin already exists" });
    }
  
   
    const hashedPassword = await bcrypt.hash(password, 10); 

    const adminDetails = new Admin({
      name,
      email, 
      password:hashedPassword, 
      appid
        });

    await adminDetails.save()
    res.json({
      status: 'SUCCESS',
      message: 'Created'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
};

const loginAdmin = async (req, res, next) => {
  try {
      const { email, password } = req.body;
      if (!email || !password) {
          return res.status(400).json({
              errorMessage: "Bad request",
          });
      }
      
      const adminDetails = await Admin.findOne({ email: email});
      if (!adminDetails) {
          return res
              .status(404)
              .json({ errorMessage: "User Doesn't exist" });
      }
      const isPasswordMatched = await bcrypt.compare(
        password,
        adminDetails.password
    );
    if (!isPasswordMatched) {
      return res
          .status(401)
          .json({ errorMessage: "Invalid credentials" });
  }
      const token = jwt.sign(
          { userId: adminDetails._id },
          process.env.SECRET_KEY,
          { expiresIn: "60h" }
      );

      res.json({
          message: "User logged in",
          userId: adminDetails._id,
          token: token,
          appid: adminDetails.appid,
          name: adminDetails.name,
      });
  } catch (error) {
      next(error);
  }
};


/*
const updateUser = async (req, res) => {
  try {
    const { id } = req.params
    const { name, email, password, utype } = req.body
    await User.findByIdAndUpdate(id, { name, email, password, utype })
    res.json({
      status: 'SUCCESS',
      message: 'User updated successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}*/

const deleteAdmin = async (req, res) => {
  try {
    const { id } = req.params
    await Admin.findByIdAndDelete(id)
    res.json({
      status: 'SUCCESS',
      message: 'User deleted successfully'
    })
  } catch (error) {
    res.status(500).json({
      status: 'FAILED',
      message: 'Something went wrong'
    })
  }
}

module.exports = {
  getAdmins,
  createAdmin,
  loginAdmin,
  deleteAdmin
}