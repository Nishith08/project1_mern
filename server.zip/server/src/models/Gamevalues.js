const mongoose = require('mongoose');


const gameSchema = new mongoose.Schema(
  {
      uid: {
        type: String, 
        required: true,
      },
      gameid: {
        type: String, 
        required: true,
      },

      gamename: {
        type: String, 
        required: true,
      },

      appid: {
        type: String,
      },
     
      gameclubid: {
        type: String,
      },
     
     
},
{ timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model('Gamevalue', gameSchema);