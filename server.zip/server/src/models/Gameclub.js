const mongoose = require('mongoose');


const gameclubSchema = new mongoose.Schema(
  {
      gameclubname: {
        type: String,
        required: true,
      },
      appid: {
        type: String,
      },
        opentime: {
          type: Date,
          required: true,
        },
      closetime: {
        type: Date,
        required: true,
      },
      openResults: {
        type: String,
      },
      closeResults: {
        type: String,
      },
      status: {
        type: String,
        required: true,
      },
      
},
{ timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model('Game', gameclubSchema);
