const mongoose = require('mongoose');


const transactionSchema = new mongoose.Schema(
  {
      uid: {
        type: String,
      },
      appid: {
        type: String,
      },
      amount: {
        type: String,
        required: true,
        unique: true,
      },
      comments: {
        type: String,
      },
      status: {
        type: String,
        required: true,
      },
      
      approvalRefNo: {
        type: String,
        required: true,
      },
      paymentData: {
        type: String,
        required: true,
      },
      message: {
        type: String,
        required: true,
      },

      
     
},
{ timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model('Transaction', transactionSchema);
