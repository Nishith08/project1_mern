const mongoose = require('mongoose');


const userSchema = new mongoose.Schema(
  {
      name: {
        type: String,
      },
      phone: {
        type: String,
        required: true,
        unique: true,
      },
      token: {
        type: String,
      },
      appid: {
        type: String,
        required: true,
      },
      utype: {
        type: String,
        required: true,
      },
      email: {
        type: String,
        
      },
      status:{
        type: String,
      },
        balance : {
          type: Number
        },

        winning: {
          type: String
        },

        refferalWinning: {
          type: String
        }
      
     
},
{ timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model('User', userSchema);
