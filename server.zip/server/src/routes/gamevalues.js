const express = require('express')

const { 
  getGames2
  //addGame2
} = require('../controllers/gamevalues')

const router = express.Router()

router.get('/gameentities', getGames2)
//router.post('/addgameentities', addGame2)

module.exports = router