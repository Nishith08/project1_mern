const express = require('express')

const { 
  getGames, 
  addGame, 
  editGame, 
  deleteGame,
  statusUpdate 
} = require('../controllers/gameclubs')

const router = express.Router()

router.get('/gamelist', getGames)

router.post('/addgame', addGame)
router.patch('/statusupdate/:id', statusUpdate)

router.patch('/editgame/:id', editGame)

router.delete('/deletegame/:id', deleteGame)

module.exports = router