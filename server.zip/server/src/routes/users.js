const express = require('express')

const { 
  deleteUser,
  updateUser,
  createUser,
  getUsers,
  loginAppUser,
  userStatusUpdate,

  
} = require('../controllers/users')

const router = express.Router()

router.delete('/users/:id', deleteUser)
router.patch('/users/:id', updateUser)
router.post('/adduser', createUser)
router.get('/users', getUsers)
router.post('/auth/applogin', loginAppUser)
router.patch('/userstatusupdate/:id', userStatusUpdate)
module.exports = router