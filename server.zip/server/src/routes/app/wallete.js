const express = require('express')

const { 
  getWallete,
} = require('../../controllers/app/wallete')

const router = express.Router()

router.get('/app/wallete', getWallete)
//router.post('/addgameentities', addGame2)

module.exports = router