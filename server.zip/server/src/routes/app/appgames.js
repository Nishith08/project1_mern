const express = require('express')

const { 
  getAppGamelist,
  getAppGamevalueslist,
  getSpecialGame
} = require('../../controllers/app/appgames')

const router = express.Router()

router.post('/app/gameentities', getAppGamelist)
router.get('/app/gameclublist', getAppGamevalueslist)
router.get('/app/getSpecialGame/:id', getSpecialGame)
//router.post('/addgameentities', addGame2)

module.exports = router
