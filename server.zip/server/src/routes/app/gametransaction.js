const express = require('express')

const { 
  getTransaction,
  addTransaction,
} = require('../../controllers/app/gametransaction')

const router = express.Router()

router.get('/app/transaction', getTransaction)
router.post('/app/addtransaction', addTransaction)

module.exports = router