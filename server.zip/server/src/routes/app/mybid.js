const express = require('express')

const { 
  getMybid,
} = require('../../controllers/app/mybid')

const router = express.Router()

router.get('/app/mybid', getMybid)
//router.post('/addgameentities', addGame2)

module.exports = router