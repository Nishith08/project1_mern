const express = require('express')

const { 
  getRate,
} = require('../../controllers/app/gamerates')

const router = express.Router()

router.get('/app/gamerates', getRate)
//router.post('/addgameentities', addGame2)

module.exports = router