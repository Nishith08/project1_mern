const express = require('express')

const { 
  
  
  getAdmins, 
  createAdmin, 
  loginAdmin, 
  deleteAdmin 
  
} = require('../controllers/admin')

const router = express.Router()


router.get('/admins', getAdmins)

router.post('/addadmin', createAdmin)

router.post('/adminlogin', loginAdmin)

//router.patch('/users/:id', updateUser)

router.delete('/admin/:id', deleteAdmin)

module.exports = router